SELECT    *,
          @curRank := @curRank + 1 AS `row_number`
FROM      `TELSTRA_NETWORK_DISRUPTIONS_1_severity_type_prepared`, (SELECT @curRank := 0) r
