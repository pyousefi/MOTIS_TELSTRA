SELECT 
    `id` AS `id`,
    COUNT(`log_feature`) AS `log_feature_count`,
    GROUP_CONCAT(log_feature,' ') AS `log_features`,
    COUNT(`volume`) AS `volume_count`,
    GROUP_CONCAT(volume,' ') AS `volumes`
 FROM `TELSTRA_NETWORK_DISRUPTIONS_1_log_feature_prepared`
  GROUP BY `id`
