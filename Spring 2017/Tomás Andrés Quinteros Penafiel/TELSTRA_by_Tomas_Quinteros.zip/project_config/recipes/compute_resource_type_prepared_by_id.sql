SELECT 
    `id` AS `id`,
    COUNT(`resource_type`) AS `resource_type_count`,
    GROUP_CONCAT(resource_type,' ') AS `resource_types`
 FROM `TELSTRA_NETWORK_DISRUPTIONS_1_resource_type_prepared`
  GROUP BY `id`
