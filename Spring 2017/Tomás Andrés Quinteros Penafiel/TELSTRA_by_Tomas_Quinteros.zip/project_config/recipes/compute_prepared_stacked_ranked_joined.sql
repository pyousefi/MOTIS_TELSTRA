SELECT 
    `train_test_prepared_stacked`.`id` AS `id`,
    `train_test_prepared_stacked`.`location` AS `location`,
    `train_test_prepared_stacked`.`fault_severity` AS `fault_severity`,
    `severity_type_prepared_ranked`.`severity_type` AS `severity_type`,
    `severity_type_prepared_ranked`.`@curRank := 0` AS `@curRank := 0`,
    `severity_type_prepared_ranked`.`row_number` AS `row_number`
  FROM `TELSTRA_NETWORK_DISRUPTIONS_1_train_test_prepared_stacked` `train_test_prepared_stacked`
  LEFT JOIN `TELSTRA_NETWORK_DISRUPTIONS_1_severity_type_prepared_ranked` `severity_type_prepared_ranked`
    ON `train_test_prepared_stacked`.`id` = `severity_type_prepared_ranked`.`id`
ORDER BY `row_number`