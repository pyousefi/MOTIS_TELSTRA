SELECT 
    `id` AS `id`,
    COUNT(`event_type`) AS `event_type_count`,
    GROUP_CONCAT(event_type,' ') AS `event_types`
 FROM `TELSTRA_NETWORK_DISRUPTIONS_1_event_type_prepared`
  GROUP BY `id`
